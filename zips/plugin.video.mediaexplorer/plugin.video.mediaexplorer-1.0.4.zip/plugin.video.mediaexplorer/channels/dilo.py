# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://www.dilo.nu'

LNG = Languages({
    Languages.es: ['es'],
    Languages.en: ['en'],
    Languages.la: ['la'],
    Languages.sub_es: ['en_es']
})

QLT = Qualities({
    Qualities.rip: ['rip', 'hdrip', 'hdrvrip'],
    Qualities.hd: ['hd720'],
    Qualities.sd: ['dvdfull'],
    Qualities.hd_full: ['hdfull', 'hd1080'],
    Qualities.scr: ['screener']
})

def mainlist(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="newest_episodes",
        label="Nuevos episodios",
        type="item",
        content_type='episodes'
    ))

    itemlist.append(item.clone(
        action="tvshows",
        label="Nuevas series",
        type="item",
        category='tvshow',
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        action="tvshows",
        label="Más populares de la semana",
        url=HOST + '/catalogue?sort=mosts-week',
        type="item",
        category='tvshow',
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        action="generos",
        label="Géneros",
        url=HOST + "/catalogue",
        type="item",
        category='tvshow',
        content_type='tvshows'
    ))


    """ Falla este filtro en la web
    itemlist.append(item.clone(
        action="newest_episodes",
        label="Capitulos de estreno en español",
        url=HOST + '/ajax/getEpisodes.php?audio=es',
        type="item",
        lang=LNG.get('es'),
        content_type='episodes'
    ))

    itemlist.append(item.clone(
        action="newest_episodes",
        label="Capitulos de estreno en latino",
        url=HOST + '/ajax/getEpisodes.php?audio=la',
        type="item",
        lang=LNG.get('la'),
        content_type='episodes'
    ))

    itemlist.append(item.clone(
        action="newest_episodes",
        label="Capitulos de estreno subtitulados",
        url=HOST + '/ajax/getEpisodes.php?audio=en_es',
        type="item",
        lang=LNG.get('en_es'),
        content_type='episodes'
    ))
    """

    # "Buscar"
    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        category='tvshow',
        content_type='tvshows'
    ))

    return itemlist


def newest_episodes(item):
    logger.trace()
    itemlist = list()

    if not item.url:
        item.url= HOST + '/ajax/getEpisodes.php?audio=all'

    data = httptools.downloadpage(item.url, {'referer': HOST}).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    patron = '<div class="col-lg-3 col-md-6 col-sm-12 mb-3">' \
             '<a class="media" href="([^"]+).*?src="([^"]+).*?' \
             '<div class="font-weight-500 txt-size-16 text-truncate" style="max-width: 97%">([^<]+)' \
             '</div><div>([^<]+)</div>'

    for url, thumb, tvshowtitle, season_episode in scrapertools.find_multiple_matches(data,patron):
        num_season, num_episode = scrapertools.get_season_and_episode(season_episode)
        itemlist.append(item.clone(
            tvshowtitle=tvshowtitle,
            label=tvshowtitle,
            thumb=thumb.replace('90x60@', '448x256@'),
            url=url,
            action="findvideos",
            episode=num_episode,
            season=num_season,
            type='episode',
            content_type='servers'
        ))

    # Paginador
    total = len(itemlist)
    ini = item.next_page if item.next_page else 0
    item.next_page = ini + 25
    itemlist = itemlist[ini:item.next_page]

    if total > item.next_page:
        itemlist.append(item.clone(
            type='next'
        ))

    return itemlist


def tvshows(item):
    logger.trace()
    itemlist = list()

    if not item.url:
        item.url=HOST + '/catalogue?sort=latest'

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    patron = 'div class="col-lg-2 col-md-3 col-6 mb-3"><a href="([^"]+)" ' \
             'class="shadow-sm d-block ASj8Fbab position-relative"><img src="([^"]+).*?' \
             '<div class="text-white txt-size-14 font-weight-500">([^<]+)' \
             '</div><div class="txt-gray-200 txt-size-12">(\d+).*?' \
             '<div class="description">(.*?)</div>'

    for url, poster, tvshowtitle, year, plot in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            action='seasons',
            label=tvshowtitle,
            tvshowtitle=tvshowtitle,
            title=tvshowtitle,
            year=year,
            url=url,
            poster=poster,
            plot=plot,
            type='tvshow',
            content_type='seasons'))

    next_page = scrapertools.find_single_match(data, '<li class="page-item"><a href="([^"]+)" aria-label="Netx">')
    if next_page:
        itemlist.append(item.clone(
            url=HOST + '/catalogue' + next_page,
            type='next'
        ))


    return itemlist


def generos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    data = scrapertools.find_single_match(data, 'Todos los generos(.*?)<div class="dropdown YaGWbeaaab">')

    generos = scrapertools.find_multiple_matches(data, '<label class="custom-control-label" for=".*?">([^<]+)</label>')
    for genero in sorted(generos):
        itemlist.append(item.clone(
            action="tvshows",
            label=genero,
            type='item',
            url= HOST + '/catalogue?genre[]=%s' % genero
        ))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    item.id = scrapertools.find_single_match(httptools.downloadpage(item.url).data, '"item_id": (\d+)')
    data =  httptools.downloadpage(HOST + '/api/web/seasons.php',{'item_id':item.id},{'referer': item.url}).data
    patron = '"number":"([^"]+)","permalink":"([^"]+)","description":"([^"]*)","picture":"([^"]*)"'
    for season, url, plot, poster in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            action="episodes",
            season=int(season),
            type='season',
            plot=plot,
            poster=('https://cdn.dilo.nu/resize/poster/250x350@' + poster) if poster else item.poster,
            content_type='episodes'
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(HOST + '/api/web/episodes.php',{'item_id':item.id, 'season_number': item.season},
                                      {'referer': item.url}).data
    patron = '"number":"([^"]+)","name":"([^"]*)","permalink":"([^"]+)",' \
             '"picture":"([^"]*)","description":"([^"]*)","audio":"([^}]*)'

    for num_episode, title, url, thumb, plot, langs in scrapertools.find_multiple_matches(data, patron):
        langs = [LNG.get(l) for l in scrapertools.find_multiple_matches(langs[:-1].replace('\\', ''),
                                                    '<img src="https://cdn.dilo.nu/languajes/(.*?)\.png')]
        if langs:
            itemlist.append(item.clone(
                title=title,
                url='%s/%s/' % (HOST, url),
                action="findvideos",
                episode=int(num_episode),
                lang=langs,
                type='episode',
                content_type='servers'
            ))

    return itemlist


def search(item):
    logger.trace()
    item.url = HOST + '/search?s=%s' % item.query.replace(" ", "+")

    return tvshows(item)


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    patron = 'data-link="([^"]+).*?<div class="font-weight-500">([^<]+).*?' \
             '<img src="https://cdn.dilo.nu//languajes/(.*?)\.png" width="20"></span>' \
             '<span class="ywM9Fbab" style="display: none">([^<]+)</span></div>'

    for url, server, lang, tipo in scrapertools.find_multiple_matches(data, patron):
        lang = LNG.get(lang)
        if item.lang and type(item.lang) != list and item.lang != lang:
            continue

        itemlist.append(item.clone(
            url=url,
            server=server.strip().lower(),
            action='play',
            type='server',
            lang=lang,
            stream=(tipo.startswith('Reproducir'))
        ))

    return servertools.get_servers_from_id(itemlist)


def play(item):
    logger.trace()
    url = item.url
    try:
        data = httptools.downloadpage(url).data
        item.url = httptools.downloadpage(scrapertools.find_single_match(data, 'src="([^"]+)'),
                    headers={'Referer': url}, follow_redirects=False).headers['location']
        servertools.normalize_url(item)
    except:
        item.url = url

    return item