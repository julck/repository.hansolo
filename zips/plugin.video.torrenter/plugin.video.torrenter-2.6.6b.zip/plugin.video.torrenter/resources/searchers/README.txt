Moved to MyShows.me Kodi Repo, please install from it.

https://bitbucket.org/DiMartino/myshows.me-kodi-repo/downloads/repository.myshows.me.zip